## 2016-01-23 Release 1.0.0
### Summary

#### Features

- Added installation of new Java Plugin 8 Update 71 (64-bit)

- Added string to uninstall outdated Java Plugin 8 Update 66 (64-bit)

#### Bugfixes
- Fixed issue with uninstall strings with wrong end character
